-- ============================================================
-- PB CRM : Supabase schema (RESET + CREATE)
-- Paste ALL of this into Supabase SQL Editor and click Run.
-- ============================================================

-- 0) Clean up any partial objects from previous attempts
drop table if exists public.returns cascade;
drop table if exists public.prospects cascade;
drop table if exists public.clients cascade;
drop table if exists public.profiles cascade;
drop function if exists public.check_member_limit() cascade;

-- 1) Team member profiles (max 3 members)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  created_at timestamptz default now()
);

create or replace function public.check_member_limit()
returns trigger
language plpgsql security definer as $$
begin
  if (select count(*) from public.profiles) >= 3 then
    raise exception '가입 정원(3명)이 모두 찼습니다.';
  end if;
  return new;
end; $$;

create trigger member_limit
before insert on public.profiles
for each row execute function public.check_member_limit();

-- 2) Clients
create table public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type text default '개인',
  family text,
  manager text,
  grade text default 'B',
  aum numeric,
  phone text,
  email text,
  memo text,
  categories text[] default '{}',
  wrap jsonb,
  created_at timestamptz default now()
);

-- 3) Return history
create table public.returns (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  base_date date not null,
  rate numeric not null,
  value numeric,
  memo text,
  created_at timestamptz default now()
);

-- 4) Prospects
create table public.prospects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  manager text,
  expected_asset numeric,
  cycle int default 30,
  last_contact date,
  source text,
  memo text,
  interests text[] default '{}',
  created_at timestamptz default now()
);

-- 5) Row Level Security
alter table public.profiles  enable row level security;
alter table public.clients   enable row level security;
alter table public.returns   enable row level security;
alter table public.prospects enable row level security;

create policy "team read profiles"  on public.profiles  for select to authenticated using (true);
create policy "insert own profile"  on public.profiles  for insert to authenticated with check (auth.uid() = id);

create policy "team all clients"    on public.clients   for all to authenticated using (true) with check (true);
create policy "team all returns"    on public.returns   for all to authenticated using (true) with check (true);
create policy "team all prospects"  on public.prospects for all to authenticated using (true) with check (true);
